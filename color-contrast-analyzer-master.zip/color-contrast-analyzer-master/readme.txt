version 2.4
the property to check for neighbouring pixel colors is added
the function is added as checkNeighbour in the app.py file at line 836

install all the required packages from the requirements.txt file:
Eg: pip install -r requirements.txt


#version 2.5

enabled support for svg and tiff images.

#version 2.5.1 (patch update)

fixed-
all colors reflecting in 'ignored_colors' image


